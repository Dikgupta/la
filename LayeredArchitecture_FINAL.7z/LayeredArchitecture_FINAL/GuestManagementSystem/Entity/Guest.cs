﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    /// <summary>
    /// Entity to store Guest Information
    /// Author: Mr. Nachiket Inamdar
    /// Date Modified: 8th march 2017
    /// Version No:
    /// Change Description:
    /// </summary>
    public class Guest
    {
        /// <summary>
        /// Property to store and retrieve GuestID
        /// </summary>
        public int GuestID { get; set; }
        /// <summary>
        /// Property to store and retrieve GuestName
        /// </summary>
        public string GuestName { get; set; }
        /// <summary>
        /// Property to store and retrieve GuestContactNo
        /// </summary>
        public long ContactNo { get; set; }
    }
}
